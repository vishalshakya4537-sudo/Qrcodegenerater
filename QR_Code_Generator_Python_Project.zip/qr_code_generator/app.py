"""QR Code Generator — beginner-friendly Tkinter desktop application."""
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import qrcode
from PIL import ImageTk


class QRGeneratorApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        root.title("QR Code Generator")
        root.geometry("520x620")
        root.minsize(440, 540)
        root.configure(bg="#f4f6fb")
        self.qr_image = None
        self.preview_image = None

        container = ttk.Frame(root, padding=24)
        container.pack(fill="both", expand=True)
        ttk.Label(container, text="QR Code Generator", font=("Arial", 22, "bold")).pack(pady=(4, 8))
        ttk.Label(container, text="Enter text or a URL, then generate and save your QR code.", wraplength=420).pack(pady=(0, 18))
        ttk.Label(container, text="Text or URL:").pack(anchor="w")
        self.text_field = tk.Text(container, height=5, wrap="word", font=("Arial", 11))
        self.text_field.pack(fill="x", pady=(6, 12))
        self.text_field.focus_set()

        ttk.Button(container, text="Generate QR Code", command=self.generate).pack(fill="x", pady=(0, 8))
        ttk.Button(container, text="Save as PNG", command=self.save).pack(fill="x")
        self.preview_label = ttk.Label(container, text="Your QR code will appear here.", anchor="center")
        self.preview_label.pack(expand=True, pady=(20, 10))
        self.status = ttk.Label(container, text="Ready", anchor="center")
        self.status.pack(fill="x", pady=(0, 8))

    def generate(self) -> None:
        data = self.text_field.get("1.0", "end-1c").strip()
        if not data:
            messagebox.showwarning("Missing text", "Please enter text or a URL first.")
            return
        qr = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=10, border=4)
        qr.add_data(data)
        try:
            qr.make(fit=True)
            self.qr_image = qr.make_image(fill_color="black", back_color="white").convert("RGB")
            preview = self.qr_image.copy()
            preview.thumbnail((290, 290))
            self.preview_image = ImageTk.PhotoImage(preview)
            self.preview_label.configure(image=self.preview_image, text="")
            self.status.configure(text="QR code generated successfully!")
        except Exception as exc:
            messagebox.showerror("Generation error", str(exc))

    def save(self) -> None:
        if self.qr_image is None:
            messagebox.showinfo("Nothing to save", "Generate a QR code first.")
            return
        file_path = filedialog.asksaveasfilename(
            title="Save QR Code", defaultextension=".png", initialfile="qr_code.png",
            filetypes=[("PNG image", "*.png")]
        )
        if file_path:
            try:
                self.qr_image.save(Path(file_path))
                self.status.configure(text=f"Saved: {Path(file_path).name}")
                messagebox.showinfo("Saved", f"QR code saved to:\n{file_path}")
            except OSError as exc:
                messagebox.showerror("Save error", str(exc))


if __name__ == "__main__":
    window = tk.Tk()
    QRGeneratorApp(window)
    window.mainloop()
