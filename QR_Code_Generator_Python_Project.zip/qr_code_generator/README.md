# QR Code Generator (Python GUI)

A beginner-friendly desktop QR Code Generator built with Python, Tkinter, `qrcode`, and Pillow. Enter a text message or URL, generate a QR code, preview it, and save it as a PNG image.

## Requirements
- Python 3.10+
- Tkinter (usually bundled with Python; on macOS use a Python installation with Tk support)

## Run
```bash
cd qr_code_generator
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```
On Windows, activate your environment with `.venv\Scripts\activate` and run `python app.py`.

## Features
- Converts any text or URL into a QR code
- Preview within a simple desktop UI
- Save as PNG
- Basic error handling for empty input and save errors

## Resume description
**QR Code Generator | Python, Tkinter, qrcode, Pillow**
- Built a desktop QR code generator with a Tkinter GUI for converting text and URLs into QR codes.
- Added image preview, PNG export, and input validation.
